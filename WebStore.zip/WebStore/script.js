// Static Data
const sampleData = {
    categories: [
        {
            id: 1,
            name: 'Electronics',
            subcategories: [
                {
                    id: 101,
                    name: 'Laptops',
                    items: [
                        { id: 1001, name: 'Dell Laptop', price: 10000.00 },
                        { id: 1002, name: 'HP Laptop', price: 12000.00 }
                    ]
                },
                {
                    id: 102,
                    name: 'Smartphones',
                    items: [
                        { id: 1003, name: 'IPhone 15', price: 30000.00 },
                        { id: 1004, name: 'HUAWEI P50 Pro', price: 18000 }
                    ]
                }
            ]
        },
        {
            id: 2,
            name: 'Clothing',
            subcategories: [
                {
                    id: 201,
                    name: 'Men',
                    items: [
                        { id: 1005, name: 'Shirt', price: 250.00 },
                        { id: 1006, name: 'Jeans', price: 550.00 }
                    ]
                },
                {
                    id: 202,
                    name: 'Women',
                    items: [
                        { id: 1007, name: 'Dress', price: 300.00 },
                        { id: 1008, name: 'Skirt', price: 400.00 }
                    ]
                }
            ]
        }
    ],
    customers: [
        { name: 'Game', categories: ['Electronics'] },
        { name: 'Zara', categories: ['Clothing'] },
        { name: 'Takealot', categories: ['Electronics', 'Clothing'] }
    ]
};

// The below is to load categories
function categoryByCustomer(customerName) {
    const categoriesDiv = document.getElementById('categories');
    categoriesDiv.innerHTML = '<h2>Categories</h2>';

    sampleData.categories.forEach(category => {
        const categoryDiv = document.createElement('div');
        categoryDiv.innerHTML = `<div class="category" onclick="productByCategoryAndCustomer(${category.id}, '${customerName}')">${category.name}</div>`;
        categoriesDiv.appendChild(categoryDiv);
    });
}

// Get products by category and customer
function productByCategoryAndCustomer(categoryId, customerName) {
    const productsDiv = document.getElementById('products');
    productsDiv.innerHTML = '<h2>Products</h2>';

    const customer = sampleData.customers.find(c => c.name === customerName);

    if (customer) {
        const allowedCategories = customer.categories;
        const category = sampleData.categories.find(c => c.id === categoryId);

        if (category && allowedCategories.includes(category.name)) {
            category.subcategories.forEach(subcategory => {
                const subcategoryDiv = document.createElement('div');
				subcategoryDiv.innerHTML = `<div class="subcategory"><strong>${subcategory.name}</strong></div>`;

                subcategory.items.forEach(item => {
                    subcategoryDiv.innerHTML += `<div class="item" onclick="addToCart(${item.id})">${item.name} - R${item.price}</div>`;
                });

                productsDiv.appendChild(subcategoryDiv);
            });
        }
    }
}

// Pass customer name to get sampleData according to that customer e.g. Takealot shows all categories
// The first two customers each have their own category
// Change the below to test this
categoryByCustomer('Takealot');
